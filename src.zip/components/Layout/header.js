import React, { useState, useEffect } from "react";
import "../../css/MainHeader.css";
import { useNavigate } from "react-router-dom";
import Login from "../../login";

export default function Header() {
  const movePage = useNavigate();
  const [isLoggedIn, setIsLoggedIn] = useState(
    Boolean(localStorage.getItem("token"))
  );

  useEffect(() => {
    const intervalId = setInterval(() => {
      setIsLoggedIn(Boolean(localStorage.getItem("token")));
    }, 1000);
    return () => clearInterval(intervalId);
  }, []);

  function handleLoginSuccess() {
    setIsLoggedIn(true);
  }

  function goMypage() {
    movePage("/mypage");
  }

  function goBoard() {
    movePage("/Board");
  }

  function goHome() {
    movePage("/");
  }

  function goMemberShip() {
    movePage("/membership");
  }

  return (
    <header>
      <div>
        <nav className="NavMenu">
          <Login onLoginSuccess={handleLoginSuccess} />

          {isLoggedIn ? (
            <button onClick={goMypage} className="NavMenuTitle">
              마이페이지
            </button>
          ) : (
            <button onClick={goMemberShip} className="NavMenuTitle">
              회원가입
            </button>
          )}
          <button onClick={goBoard} className="NavMenuTitle">
            고객지원
          </button>
        </nav>

        <br />

        <div onClick={goHome}>
          <h1 className="Title">P H O P O</h1>
        </div>
      </div>
    </header>
  );
}
